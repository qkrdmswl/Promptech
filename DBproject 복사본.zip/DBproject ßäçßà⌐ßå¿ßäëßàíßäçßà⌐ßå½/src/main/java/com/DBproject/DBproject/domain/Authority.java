package com.DBproject.DBproject.domain;

public enum Authority {
    ADMIN,BASIC,CEO
}
