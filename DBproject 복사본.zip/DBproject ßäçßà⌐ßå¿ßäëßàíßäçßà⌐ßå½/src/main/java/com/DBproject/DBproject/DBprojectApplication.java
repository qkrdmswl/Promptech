package com.DBproject.DBproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DBprojectApplication {

	public static void main(String[] args) {

		SpringApplication.run(DBprojectApplication.class, args);

	}

}
