package com.DBproject.DBproject.exception;

public class NoIdException extends CustomException{
    private static final long serialVersionUID = -7799696001358188839L;
    public NoIdException(String message) {

        super(message);}
    }

