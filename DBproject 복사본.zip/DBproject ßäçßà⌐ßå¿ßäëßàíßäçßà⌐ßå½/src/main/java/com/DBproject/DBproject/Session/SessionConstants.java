package com.DBproject.DBproject.Session;

public interface SessionConstants {

    String LoginMember = "loginMember";
}
