package com.DBproject.DBproject.repository;

public class RegisterRepository {
}
